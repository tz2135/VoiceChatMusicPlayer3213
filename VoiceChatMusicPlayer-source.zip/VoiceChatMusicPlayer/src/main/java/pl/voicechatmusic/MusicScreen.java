package pl.voicechatmusic;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;

import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import java.nio.file.Path;

public class MusicScreen extends Screen {
    private String status = "Choose an MP3 file";
    private MusicScreen(String title) { super(Text.literal(title)); }
    public MusicScreen() { this("VoiceChat Music Player"); }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = height / 2 - 65;
        addDrawableChild(ButtonWidget.builder(Text.literal("Open MP3"), b -> chooseFile()).dimensions(cx - 100, y, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Play"), b -> VoiceChatMusicClient.ENGINE.play()).dimensions(cx - 100, y + 28, 62, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Pause"), b -> VoiceChatMusicClient.ENGINE.pause()).dimensions(cx - 31, y + 28, 62, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Stop"), b -> VoiceChatMusicClient.ENGINE.stop()).dimensions(cx + 38, y + 28, 62, 20).build());
        addDrawableChild(new SliderWidget(cx - 100, y + 60, 200, 20, Text.literal("Volume"), VoiceChatMusicClient.ENGINE.volume()) {
            @Override protected void updateMessage() { setMessage(Text.literal("Volume: " + Math.round(value * 100) + "%")); }
            @Override protected void applyValue() { VoiceChatMusicClient.ENGINE.setVolume((float) value); }
        });
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(cx - 100, y + 91, 200, 20).build());
    }

    private void chooseFile() {
        Thread t = new Thread(() -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select MP3 file");
            chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("MP3 audio", "mp3"));
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                Path path = chooser.getSelectedFile().toPath();
                MinecraftClient.getInstance().execute(() -> {
                    status = "Loading: " + path.getFileName();
                    VoiceChatMusicClient.ENGINE.load(path);
                });
            }
        }, "VoiceChat-Music-FilePicker");
        t.setDaemon(true);
        t.start();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 92, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(VoiceChatMusicClient.ENGINE.currentFile()), width / 2, height / 2 + 58, 0xCCCCCC);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Broadcast is mixed into your microphone; nearby players hear it."), width / 2, height / 2 + 72, 0xAAAAAA);
    }

    @Override public boolean shouldPause() { return false; }
}
