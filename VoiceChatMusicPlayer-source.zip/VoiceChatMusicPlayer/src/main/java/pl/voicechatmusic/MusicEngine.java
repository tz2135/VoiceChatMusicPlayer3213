package pl.voicechatmusic;

import de.maxhenkel.voicechat.api.VoicechatClientApi;
import de.maxhenkel.voicechat.api.mp3.Mp3Decoder;

import javax.sound.sampled.AudioFormat;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicBoolean;

public class MusicEngine {
    private volatile short[] pcm = new short[0];
    private volatile int cursor = 0;
    private volatile float volume = 0.65f;
    private volatile boolean playing = false;
    private volatile VoicechatClientApi api;
    private final AtomicBoolean loading = new AtomicBoolean(false);
    private volatile String currentFile = "No file selected";

    public void setApi(VoicechatClientApi api) { this.api = api; }
    public boolean isPlaying() { return playing; }
    public String currentFile() { return currentFile; }
    public float volume() { return volume; }
    public void setVolume(float value) { volume = Math.max(0f, Math.min(1f, value)); }

    public void load(Path file) {
        VoicechatClientApi voiceApi = api;
        if (voiceApi == null || !loading.compareAndSet(false, true)) return;
        playing = false;
        Thread worker = new Thread(() -> {
            try {
                Mp3Decoder decoder = voiceApi.createMp3Decoder(Files.newInputStream(file));
                if (decoder == null) throw new IOException("Simple Voice Chat MP3 decoder unavailable");
                short[] decoded = decoder.decode();
                AudioFormat format = decoder.getAudioFormat();
                if (format.getChannels() == 2) {
                    short[] mono = new short[decoded.length / 2];
                    for (int i = 0; i < mono.length; i++) mono[i] = (short) ((decoded[i * 2] + decoded[i * 2 + 1]) / 2);
                    decoded = mono;
                }
                if ((int) format.getSampleRate() != 48000) {
                    decoded = resample(decoded, (int) format.getSampleRate(), 48000);
                }
                pcm = decoded;
                cursor = 0;
                currentFile = file.getFileName().toString();
            } catch (Exception e) {
                currentFile = "Error: " + e.getMessage();
                pcm = new short[0];
            } finally {
                loading.set(false);
            }
        }, "VoiceChat-MP3-Decoder");
        worker.setDaemon(true);
        worker.start();
    }

    public void play() { if (pcm.length > 0) playing = true; }
    public void pause() { playing = false; }
    public void stop() { playing = false; cursor = 0; }

    public synchronized short[] nextPcmFrame(int requestedSamples) {
        if (!playing || pcm.length == 0) return null;
        short[] out = new short[requestedSamples];
        for (int i = 0; i < requestedSamples; i++) {
            if (cursor >= pcm.length) { playing = false; break; }
            out[i] = (short) (pcm[cursor++] * volume);
        }
        return out;
    }

    private static short[] resample(short[] input, int fromRate, int toRate) {
        if (fromRate <= 0 || input.length == 0) return input;
        int outLength = (int) ((long) input.length * toRate / fromRate);
        short[] out = new short[outLength];
        for (int i = 0; i < outLength; i++) {
            double source = (double) i * fromRate / toRate;
            int a = Math.min((int) source, input.length - 1);
            int b = Math.min(a + 1, input.length - 1);
            double f = source - a;
            out[i] = (short) (input[a] * (1.0 - f) + input[b] * f);
        }
        return out;
    }
}
