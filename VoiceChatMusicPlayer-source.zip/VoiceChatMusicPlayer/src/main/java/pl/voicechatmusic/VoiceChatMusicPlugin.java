package pl.voicechatmusic;

import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatClientApi;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MergeClientSoundEvent;

public class VoiceChatMusicPlugin implements VoicechatPlugin {
    private static VoicechatClientApi clientApi;

    @Override
    public String getPluginId() {
        return "voicechat_music_player";
    }

    @Override
    public void initialize(VoicechatApi api) {
        if (api instanceof VoicechatClientApi client) {
            clientApi = client;
            VoiceChatMusicClient.ENGINE.setApi(client);
        }
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(MergeClientSoundEvent.class, event -> {
            short[] music = VoiceChatMusicClient.ENGINE.nextPcmFrame(event.getAudio().length);
            if (music == null) return;
            short[] mic = event.getAudio();
            for (int i = 0; i < mic.length; i++) {
                int mixed = mic[i] + music[i];
                mic[i] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, mixed));
            }
        });
    }
}
